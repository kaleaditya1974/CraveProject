Run following commands in terminal
1. cd project
2. npm install
3. npm start

Head to localhost:3000
In case port is already in use, change port number in project/server/main.js