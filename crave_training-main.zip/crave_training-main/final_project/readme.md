- Run following commands in terminal
  1. `cd final_project`
  2. `npm install` (to install all required dependencies)
  3. `npm start` (to run the application with nodemon) 
**Note**: Application can be run with `node .\server\server.js` 

- Head to `localhost:3000` to load `index.html`
- In case port is already in use, change port number in `project/server/server.js`

- Ensure internet connectivity for jquery cdn
