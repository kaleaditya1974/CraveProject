package com.animal;

public class Lion extends Animal{
	@Override
	public void talk() {
		System.out.println("roar");
	}
}
