package com.animal;

public class Dog extends Animal{
	@Override
	public void talk() {
		System.out.println("bark");
	}
}
