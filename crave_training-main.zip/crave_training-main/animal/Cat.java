package com.animal;

public class Cat extends Animal{
	@Override
	public void talk() {
		System.out.println("purr");
	}
}
