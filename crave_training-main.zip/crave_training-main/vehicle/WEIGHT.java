package f13;

public enum WEIGHT {
	VERY_LIGHT,LIGHT,MEDIUM,HEAVY,VERY_HEAVY;
}
