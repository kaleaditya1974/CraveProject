package com.sorter;

public interface Sortable<T> {
	public void sort(T[] s);
	public void print();
}
